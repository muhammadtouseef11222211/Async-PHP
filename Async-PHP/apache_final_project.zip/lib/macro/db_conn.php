<?php
include 'macro_db.php'; // Include the include function

// Use the db_connect function
$conn = db_connect("mysql-26efb892-muhammadtou420-27e1.c.aivencloud.com", "avnadmin", "AVNS_rIWbK0jA00JibIIZ1W1", "test", 14786);




?>

