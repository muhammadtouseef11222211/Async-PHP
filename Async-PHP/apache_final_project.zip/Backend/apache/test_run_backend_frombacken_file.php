<form id="name-form">
    <input type="text" id="name" name="name" placeholder="Enter your name">

<button class="btn btn-primary mb-3 runScripts" data-url="../Backend/apache/apache_status.php:output2">Run Test 3</button>

</form>
<div id="output2" class="bg-light p-3"></div>

